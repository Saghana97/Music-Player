import React, { Component } from "react";
import "./AudioPlayer.css";
//audio player to play the songs in the player
class AudioPlayer extends Component {
  render() {
    return (
      <div className="audio-wrapper">
        <p>{this.state.playingSong}</p>
        <audio controls autoPlay>
          <source src={this.state.playingSongName} />
        </audio>
      </div>
    );
  }
}

export default AudioPlayer;
