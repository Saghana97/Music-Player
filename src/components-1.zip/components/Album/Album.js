import React, { Component } from "react";
import "./Album.css";
import data from "../../helpers/data";
import AlbumDetail from "../AlbumDetail/AlbumDetail";
import { Dialog } from "@material-ui/core";
import QueueSong from "../QueueSong/QueueSong";
import AlbumContent from "../AlbumContent/AlbumContent";
import AudioPlayer from "../AudioPlayer/AudioPlayer";
//storing the file in a base 64 format
const getBase64 = file => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = error => reject(error);
    reader.readAsDataURL(file);
  });
};

//component album for the player
class Album extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      album_text: "",
      album_image: "",
      queue: [],
      queue_name: [],
      artist_name: [],
      data: data,
      callComponent: false,
      modalOpen: false,
      currentAlbumIndex: null,
      currentSongList: []
    };
  }
  //getting the details of the album
  getDetail = (e, index, songs) => {
    e.stopPropagation();
    e.preventDefault();
    this.setState({
      modalOpen: true,
      currentAlbumIndex: index,
      currentSongList: songs
    });
  };

  handleSecondClose = () => {
    this.setState({ modalOpen: false });
  };
  //setting state for the album
  addAlbum = () => {
    this.setState({ open: true });
  };
  handleClose = () => {
    this.setState({ open: false });
  };
  //getting the name of the album
  getName = e => {
    this.setState({ album_text: e.target.value });
  };
  //function to add the data to the album content
  addToData = () => {
    data.push({
      album_name: this.state.album_text,
      album_image: this.state.album_image,
      songs: []
    });
    this.setState({ open: false });
  };
  //get the file and store it in a base 64 format
  getFile = e => {
    const file = e.target.files[0];
    getBase64(file).then(base64 => {
      this.setState({ album_image: base64 });
    });
  };

  componentWillReceiveProps() {
    console.log(" will receieve");
  }

  componentWillUpdate() {
    console.log("update");
  }

  componentDidUpdate() {
    console.log("did");
  }

  componentWillMount() {
    console.log("data");
  }
  //function to delete the album
  deleteAlbum = (e, index) => {
    e.preventDefault();
    e.stopPropagation();
    this.state.data.splice(index, 1);
    this.setState({
      data: this.state.data
    });
  };
  //add all the songs to the queue
  addAllToQueue = () => {
    const { data, queue, queue_name, artist_name } = this.state;
    for (var i = 0; i < data.length; i++) {
      for (var j = 0; j < data[i].songs.length; j++) {
        if (data[i].songs[j].song) {
          queue.push(data[i].songs[j].song);
          queue_name.push(data[i].songs[j].song_name);
          queue_name.push(data[i].songs[j].song_name);
          artist_name.push(data[i].songs[j].artist_name);
        }
      }
    }
  };

  render() {
    return (
      <div className="album-wrapper Maindiv">
        <div className="Contentdiv">
          <div className="heading">
            <p> Your Albums </p>
          </div>
          <div className="add-album">
            <button className="add" onClick={this.addAlbum}>
              {" "}
              Add new album{" "}
            </button>
            <button className="add" onClick={this.addAllToQueue}>
              Add all to queue
            </button>
          </div>
          <Dialog
            open={this.state.open}
            onClose={this.handleClose}
            className="form-dialog"
          >
            <div className="form">
              <input
                type="text"
                id="album_name"
                className="input"
                placeholder="Album Name"
                onChange={this.getName}
              />{" "}
              <br />
              <p> Upload a cover image</p>
              <input
                type="file"
                name="pic"
                accept="image/*"
                className="input-file"
                onChange={this.getFile}
                id="picture"
              />
              <div className="button">
                <button className="add-album-button" onClick={this.addToData}>
                  {" "}
                  Add{" "}
                </button>
              </div>
            </div>
          </Dialog>
          <div className="album-container">
            {this.state.data &&
              this.state.data.length > 0 &&
              this.state.data.map((datum, index) => (
                <div key={index}>
                  <div
                    className="album-detail-wrapper"
                    onClick={e => this.getDetail(e, index, datum.songs)}
                  >
                    <div
                      className="album-image"
                      style={{
                        backgroundImage: "url(" + datum.album_image + ")"
                      }}
                    />
                    <div className="album-name"> {datum.album_name} </div>
                    <div />
                    <button onClick={e => this.deleteAlbum(e, index)}>
                      {" "}
                      Delete{" "}
                    </button>
                  </div>
                </div>
              ))}
            <Dialog
              open={this.state.modalOpen}
              onClose={this.handleSecondClose}
            >
              <div className="content">
                <AlbumContent
                  albumIndex={this.state.currentAlbumIndex}
                  songs={this.state.currentSongList}
                  data={this.state.data}
                  queue={this.state.queue}
                  contentModal={this.state.modalOpen}
                  queueSongName={this.state.queue_name}
                  artistName={this.state.artist_name}
                />
              </div>
            </Dialog>
          </div>
        </div>
        <div className="Queuediv">
          <p className="playListSongs"> QUEUE </p>
          {this.state.data &&
            this.state.queue_name.map((song, index) => (
              <QueueSong
                name={song}
                id={index}
                artist_name={this.state.artist_name[index]}
                playSong={this.state.queue[index]}
                allSongs={this.state.queue}
                allSongsName={this.state.queue_name}
              />
            ))}
        </div>
      </div>
    );
  }
}

export default Album;
